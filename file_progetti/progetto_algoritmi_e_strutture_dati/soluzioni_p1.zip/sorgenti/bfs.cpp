#include <bits/stdc++.h>
using namespace std;
#define MAXN 50001
#define MAXM 500001
#define MAXQ 50001

int N, M, Q;
vector<vector<int>> graph;

int solve(int source, int target){
    vector<int> d(N+1,-1);
    queue<int> q;
    q.push(source);
    d[source] = 0;

    int u, v;
    while(!q.empty()) {
        u = q.front();
        q.pop();
        for(int i = 0; i<graph[u].size(); i++){
            v = graph[u][i];
            if (d[v] == -1) {
                d[v] = d[u]+1;
                q.push(v);
            }
            if(v == target){
                // stop
                q = queue<int>();  // empty queue
                i = graph[u].size();
            }
        }
    } 

    return d[target];
}


int main (){

    ifstream in("input.txt");
    ofstream out("output.txt");

    in >> N >> M >> Q;

    graph.resize(N+1); 

    int u, v;
    for(int i = 0; i<M; i++){
        in >> u >> v;
        graph[u].push_back(v);
        graph[v].push_back(u);
    }

    for(int i = 0; i<Q; i++){
        in >> u >> v;
        out << solve(u,v) << endl;
    }

    return 0;
}
