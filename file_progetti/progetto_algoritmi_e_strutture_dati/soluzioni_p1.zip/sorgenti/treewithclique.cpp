#include <bits/stdc++.h>
using namespace std;
#define MAXN 50001
#define MAXM 500001
#define MAXQ 50001
#define LOG 21 // ~log2(MAXN)

int N, M, Q;

vector<vector<int>> graph; // I suppose vertices are 0...N-1
vector<pair<int,int>> edges;

vector<vector<int>> graphT;
vector<int> visited;
vector<int> ft;
int counter;

vector<vector<int>> tree;

int lca[MAXN+MAXM][LOG]; // lca[i][j] = 2^j th ancestor of node i 
int h[MAXN+MAXM]; // h[i] = height of i in the tree

//////////// FIND CLIQUE AND CREATE TREE ////////////

// Visita dfs per memorizzare i tempi di fine visita.
// Costruisce il grafo trasposto rispetto a quello con gli archi dati dall'ordine della visita,
// aggiungendo anche tutti gli archi all'indietro, che quindi identificano cicli.
void dfsG(int u, int parent){
	visited[u] = true;
	for(int v : graph[u]){
		if(!visited[v]){
			dfsG(v, u);
		}
		if(v != parent){
			graphT[v].push_back(u);
		}
  }
  ft[u] = counter;
  counter++;
}

// Conta quanti elementi trova in una scc e mette tutto nel vector c.
// Questa funzione o trova un singolo nodo o il ciclo presente nell'albero.
void dfsGT(int u, int parent, vector<int>& c){
	visited[u] = true;
	c.push_back(u);
	for(int v : graphT[u]){
		if(!visited[v] && v != parent){
			dfsGT(v, u, c);
		}
	}
	counter++;
}

vector<int> findClique(){
	counter = 0;
	dfsG(0,-1); 

	for(int i = 0; i<N; i++)
		visited[i] = false;
	
	vector<pair<int,int>> lista;
	for(int i = 0; i<N; i++)
		lista.push_back(make_pair(ft[i],i));

  	sort(lista.begin(),lista.end());

  	for(int j = N-1; j>=0; j--){
  		int u = lista[j].second;
  		if(!visited[u]){
  			counter = 0;
  			vector<int> c;
  			dfsGT(u,-1,c);
  			if(counter > 1){
  				return c;
  			}
		}    
	}

	vector<int> c;
	return c; // no clique
}

void createTree(){ 
	vector<int> clique = findClique();
	vector<int> inclique; // inclique[u] = true if the node is in the clique
	inclique.resize(N+1,false);

	for(int u : clique){ // does nothing if clique is empty
		tree[N].push_back(u); // N new noode
		tree[u].push_back(N);
		inclique[u] = true; // node u is in the clique
	}

	int newnode = N+1;
	for(int i = 0; i<edges.size(); i++){
		int u = edges[i].first;
		int v = edges[i].second;
		if(!inclique[u] || !inclique[v]){ // this edge was not considered
			tree[newnode].push_back(u); 
			tree[u].push_back(newnode);
			tree[newnode].push_back(v); 
			tree[v].push_back(newnode);
			newnode++;
		}
	}
}

//////////// LCA ////////////

void preprocess(int u, int parent){
	lca[u][0] = parent;
	if(parent == -1)
		h[u] = 0;
	else 
		h[u] = h[parent] + 1;
	
	// compute all ancestors of u
	for (int i = 1; i<LOG; i++)
		if(lca[u][i-1] != -1)
			lca[u][i] = lca[lca[u][i-1]][i-1]; // 2^j th ancestor of node i = 
											   // 2^(j-1) th ancestor of 2^(j-1) th ancestor of node i
	
	// compute all ancestors of children
	for(int v : tree[u]){
		// cout << v << endl;
		if(v != parent)
			preprocess(v, u);
	}
}

int getLca(int u, int v){
	if(h[u] < h[v]) 
		swap(u, v);

	// u is the node at lower level, we raise u to be at the same level as v
    int dist = h[u]-h[v]; 
	while(dist > 0){
        int raiseby = log2(dist);
        u = lca[u][raiseby];
        dist -= pow(2,raiseby);
    }

	if(u == v) return u;

    for(int j = LOG-1; j>=0; j--){
        if(lca[u][j] != lca[v][j]){ 
            u = lca[u][j]; 
            v = lca[v][j]; 
        }
    }

	return lca[u][0]; // parent of u 
}

int solve(int u, int v){
	return (h[u]+h[v]-2*h[getLca(u,v)])/2;
}

int main (){

    ifstream in("input.txt");
    ofstream out("output.txt");

    in >> N >> M >> Q;

    tree.resize(N+M+1);
    graph.resize(N+1);
    graphT.resize(N+1);
    visited.resize(N+1,false);
    ft.resize(N+1,-1);

    int u, v;
    for(int i = 0; i<M; i++){
        in >> u >> v;
        graph[u].push_back(v);
        graph[v].push_back(u);
        edges.push_back(make_pair(u,v));
    }

    createTree();    
    preprocess(0, -1); // root of the tree = 1, parent = -1

    for(int i = 0; i<Q; i++){
        in >> u >> v;
        out << solve(u,v) << endl;
    }
	
    return 0;
}